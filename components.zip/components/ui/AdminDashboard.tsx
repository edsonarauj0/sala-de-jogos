"use client";
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Plus, Trash2, ExternalLink, Loader2 } from "lucide-react";
import Link from 'next/link';

export default function AdminDashboard() {
  const [rooms, setRooms] = useState<any[]>([]);
  const [newRoomName, setNewRoomName] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRooms();
  }, []);

  async function fetchRooms() {
    setLoading(true);
    const { data, error } = await supabase
      .from('rooms')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (!error) setRooms(data || []);
    setLoading(false);
  }

  async function createRoom() {
    if (!newRoomName) return;
    const { error } = await supabase
      .from('rooms')
      .insert([{ name: newRoomName }]);
    
    if (!error) {
      setNewRoomName('');
      fetchRooms();
    }
  }

  async function deleteRoom(id: string) {
    if (confirm("Tem certeza que deseja excluir esta sala e todos os palpites?")) {
      await supabase.from('rooms').delete().eq('id', id);
      fetchRooms();
    }
  }

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-6 min-h-screen bg-white">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-green-900 font-mono">Painel Administrativo</h1>
        <Button onClick={() => window.location.reload()} variant="ghost" size="sm">Sair</Button>
      </div>
      
      <div className="flex gap-2 bg-green-50 p-6 rounded-2xl border border-green-100 shadow-sm">
        <Input 
          placeholder="Nome da Nova Sala (ex: Chá de Panela)" 
          value={newRoomName}
          onChange={(e) => setNewRoomName(e.target.value)}
          className="bg-white border-green-200 focus:ring-green-500"
        />
        <Button onClick={createRoom} className="bg-green-600 hover:bg-green-700 px-6">
          <Plus className="mr-2 h-4 w-4" /> Criar Sala
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center p-12"><Loader2 className="animate-spin text-green-600 w-8 h-8" /></div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {rooms.length === 0 && (
            <div className="text-center py-20 border-2 border-dashed border-green-100 rounded-2xl">
              <p className="text-gray-400">Nenhuma sala encontrada. Crie uma para começar!</p>
            </div>
          )}
          
          {rooms.map((room) => (
            <Card key={room.id} className="border-green-100 hover:border-green-300 transition-colors shadow-sm">
              <CardContent className="flex items-center justify-between p-6">
                <div>
                  <h3 className="font-bold text-xl text-green-800">{room.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded font-mono">
                      ID: {room.id}
                    </span>
                  </div>
                </div>
                
                <div className="flex gap-3">
                  <Link href={`/admin/${room.id}`}>
                    <Button variant="outline" className="border-green-600 text-green-700 hover:bg-green-50">
                      Gerenciar Sala <ExternalLink className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => deleteRoom(room.id)}
                    className="text-red-300 hover:text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="h-5 w-5" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}