"use client";
import React, { useState, useEffect, use } from 'react';
import { supabase } from '@/lib/supabase';
import { FloatingFaces } from '@/components/ui/FloatingFaces';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { ConfettiEffect } from '@/components/ui/ConfettiEffect';

type Step = 'NAME' | 'JUJUBA' | 'QUIZ' | 'SUMMARY';

export default function GuestFlow({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [step, setStep] = useState<Step>('NAME');
  const [room, setRoom] = useState<any>(null);
  const [questions, setQuestions] = useState<any[]>([]);
  
  // Dados do usuário
  const [userName, setUserName] = useState('');
  const [jujubaGuess, setJujubaGuess] = useState('');
  const [quizAnswers, setQuizAnswers] = useState<Record<string, string>>({});

  useEffect(() => {
    supabase.from('rooms').select('*').eq('id', id).single().then(({data}) => setRoom(data));
    supabase.from('quiz_questions').select('*').eq('room_id', id).then(({data}) => setQuestions(data || []));
    if (localStorage.getItem(`voted_${id}`)) setStep('SUMMARY');
  }, [id]);

  const nextStep = () => {
    if (step === 'NAME') {
        if (room.jujuba_active) setStep('JUJUBA');
        else if (room.quiz_active) setStep('QUIZ');
        else finish();
    } else if (step === 'JUJUBA') {
        if (room.quiz_active) setStep('QUIZ');
        else finish();
    }
  };

  const finish = async () => {
    // Salvar Jujuba
    if (room.jujuba_active) {
        await supabase.from('guesses').insert([{ room_id: id, user_name: userName, guess_value: parseInt(jujubaGuess) }]);
    }
    // Salvar Quiz
    if (room.quiz_active) {
        const answers = Object.entries(quizAnswers).map(([qId, partner]) => ({
            room_id: id,
            question_id: qId,
            user_name: userName,
            selected_partner: partner
        }));
        await supabase.from('quiz_answers').insert(answers);
    }
    localStorage.setItem(`voted_${id}`, 'true');
    setStep('SUMMARY');
  };

  if (!room) return <div className="p-10 text-center">Carregando...</div>;

  return (
    <div className="relative min-h-screen flex items-center justify-center p-4 bg-green-50 overflow-hidden">
      <FloatingFaces />
      {room.is_revealed && <ConfettiEffect />}

      <Card className="relative z-10 w-full max-w-md bg-white/90 backdrop-blur-md border-green-200">
        <CardHeader className="text-center">
          <CardTitle className="text-green-800">{room.name}</CardTitle>
          <p className="text-sm text-green-600">Dinâmica Chá de Casa Nova</p>
        </CardHeader>
        <CardContent>

          {/* PASSO 1: NOME */}
          {step === 'NAME' && (
            <div className="space-y-4">
              <Input placeholder="Seu Nome Completo" value={userName} onChange={e => setUserName(e.target.value)} />
              <Button onClick={nextStep} disabled={!userName} className="w-full bg-green-600">Começar!</Button>
            </div>
          )}

          {/* PASSO 2: JUJUBA */}
          {step === 'JUJUBA' && (
            <div className="space-y-4 text-center">
              <div className="text-5xl mb-2">🫙</div>
              <p className="font-bold">Quantas jujubas tem no pote?</p>
              <Input type="number" placeholder="Seu palpite" value={jujubaGuess} onChange={e => setJujubaGuess(e.target.value)} />
              <Button onClick={nextStep} className="w-full bg-green-600">Próximo</Button>
            </div>
          )}

          {/* PASSO 3: QUIZ */}
          {step === 'QUIZ' && (
            <div className="space-y-6">
              <p className="text-center font-bold text-green-800">Quem é mais provável de...</p>
              <div className="max-h-80 overflow-y-auto space-y-4 px-2">
                {questions.map((q) => (
                  <div key={q.id} className="border-b pb-4">
                    <p className="text-sm mb-2">{q.question_text}</p>
                    <div className="grid grid-cols-2 gap-2">
                      <Button 
                        variant={quizAnswers[q.id] === room.partner_1 ? "default" : "outline"}
                        className={quizAnswers[q.id] === room.partner_1 ? "bg-green-600" : ""}
                        onClick={() => setQuizAnswers({...quizAnswers, [q.id]: room.partner_1})}
                      >
                        {room.partner_1}
                      </Button>
                      <Button 
                        variant={quizAnswers[q.id] === room.partner_2 ? "default" : "outline"}
                        className={quizAnswers[q.id] === room.partner_2 ? "bg-green-800" : ""}
                        onClick={() => setQuizAnswers({...quizAnswers, [q.id]: room.partner_2})}
                      >
                        {room.partner_2}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
              <Button onClick={finish} disabled={Object.keys(quizAnswers).length < questions.length} className="w-full bg-green-700">Finalizar Tudo</Button>
            </div>
          )}

          {/* PASSO FINAL: SUMMARY */}
          {step === 'SUMMARY' && (
            <div className="text-center space-y-4">
              <div className="text-5xl">🎉</div>
              <h2 className="text-2xl font-bold text-green-800">Respostas Enviadas!</h2>
              <div className="text-left bg-green-50 p-4 rounded-xl text-sm space-y-2">
                <p><b>Nome:</b> {userName || "Registrado"}</p>
                {room.jujuba_active && <p><b>Seu Palpite:</b> {jujubaGuess} jujubas</p>}
                <p className="text-xs text-green-600 pt-2 border-t">Aguarde o organizador liberar o resultado final para ver se você ganhou!</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}