"use client";

import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { QRCodeSVG } from 'qrcode.react';
import { supabase } from '@/lib/supabase';

export default function AdminPage() {
  const [correctNumber, setCorrectNumber] = useState<number>(0);
  const [guesses, setGuesses] = useState<any[]>([]);
  const [qrUrl, setQrUrl] = useState('');

  useEffect(() => {
    setQrUrl(window.location.origin);
    fetchData();
  }, []);

  async function fetchData() {
    const { data: config } = await supabase.from('config').select('*').single();
    if (config) setCorrectNumber(config.correct_number);

    const { data: allGuesses } = await supabase
      .from('guesses')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (allGuesses) setGuesses(allGuesses);
  }

  const updateCorrectNumber = async () => {
    await supabase.from('config').update({ correct_number: correctNumber }).eq('id', 1);
    alert("Número atualizado!");
    fetchData();
  };

  // Lógica do Ranking: Calcula a diferença absoluta
  const ranking = [...guesses].sort((a, b) => {
    const diffA = Math.abs(a.guess_value - correctNumber);
    const diffB = Math.abs(b.guess_value - correctNumber);
    return diffA - diffB;
  });

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-8 bg-white min-h-screen">
      <h1 className="text-3xl font-bold text-green-800">Painel do Organizador</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Configuração */}
        <Card className="border-green-200">
          <CardHeader><CardTitle>Configuração</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm">Quantidade Real no Pote</label>
              <Input 
                type="number" 
                value={correctNumber} 
                onChange={(e) => setCorrectNumber(parseInt(e.target.value))}
              />
            </div>
            <Button onClick={updateCorrectNumber} className="bg-green-600 w-full">Salvar Número Oficial</Button>
            
            <div className="flex flex-col items-center pt-4 border-t">
              <p className="text-sm mb-2 font-bold">QR Code para Convidados:</p>
              <QRCodeSVG value={qrUrl} size={150} fgColor="#166534" />
              <p className="text-xs mt-2 text-gray-500">{qrUrl}</p>
            </div>
          </CardContent>
        </Card>

        {/* Ranking */}
        <Card className="border-green-200">
          <CardHeader><CardTitle>Ranking (Mais Próximos)</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-2">
              {ranking.map((item, index) => (
                <div key={item.id} className={`flex justify-between p-3 rounded-lg ${index === 0 ? 'bg-yellow-100 border border-yellow-300' : 'bg-green-50'}`}>
                  <span>
                    <span className="font-bold mr-2">#{index + 1}</span>
                    {item.name}
                  </span>
                  <span className="font-mono font-bold">
                    {item.guess_value} 
                    <span className="text-xs text-gray-500 ml-1">
                      (diff: {Math.abs(item.guess_value - correctNumber)})
                    </span>
                  </span>
                </div>
              ))}
              {ranking.length === 0 && <p className="text-gray-500 text-center">Nenhum palpite ainda.</p>}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}