"use client";

import React, { useState, useEffect, use } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";
import { QRCodeSVG } from 'qrcode.react';
import { 
  Trophy, Users, Settings, Share2, 
  Plus, Trash2, Copy, Check, BarChart3, 
  ArrowLeft, Info, 
  Loader2
} from "lucide-react";
import Link from 'next/link';

export default function RoomAdminDetails({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [room, setRoom] = useState<any>(null);
  const [questions, setQuestions] = useState<any[]>([]);
  const [guesses, setGuesses] = useState<any[]>([]);
  const [quizStats, setQuizStats] = useState<any[]>([]);
  
  // States para Inputs (evita o erro de onChange)
  const [roomName, setRoomName] = useState("");
  const [partner1, setPartner1] = useState("");
  const [partner2, setPartner2] = useState("");
  const [targetValue, setTargetValue] = useState(0);
  const [newQuestion, setNewQuestion] = useState("");
  
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetchData();
  }, [id]);

  async function fetchData() {
    const { data: r } = await supabase.from('rooms').select('*').eq('id', id).single();
    const { data: q } = await supabase.from('quiz_questions').select('*').eq('room_id', id);
    const { data: g } = await supabase.from('guesses').select('*').eq('room_id', id);
    const { data: a } = await supabase.from('quiz_answers').select('*').eq('room_id', id);

    if (r) {
      setRoom(r);
      setRoomName(r.name);
      setPartner1(r.partner_1);
      setPartner2(r.partner_2);
      setTargetValue(r.target_value);
    }
    if (q) setQuestions(q);
    if (g) setGuesses(g);

    if (q && a && r) {
      const stats = q.map(quest => {
        const answers = a.filter(ans => ans.question_id === quest.id);
        const p1Count = answers.filter(ans => ans.selected_partner === r.partner_1).length;
        const p2Count = answers.filter(ans => ans.selected_partner === r.partner_2).length;
        return { ...quest, p1Count, p2Count, total: answers.length };
      });
      setQuizStats(stats);
    }
  }

// FUNÇÃO DE ATUALIZAÇÃO CORRIGIDA
const handleUpdateRoom = async (field: string, value: boolean | string | number) => {
  console.log(`Tentando atualizar ${field} para:`, value);
  
  // 1. Atualiza o estado local imediatamente (UI responde rápido)
  setRoom((prev: any) => ({ ...prev, [field]: value }));

  try {
    // 2. Envia para o Supabase
    const { data, error } = await supabase
      .from('rooms')
      .update({ [field]: value })
      .eq('id', id)
      .select();

    if (error) {
      console.error("Erro no Supabase:", error);
      throw error;
    }

    console.log("Sucesso ao atualizar banco:", data);
  } catch (error) {
    alert("Erro ao salvar no banco de dados. Verifique a conexão.");
    // 3. Se der erro, busca os dados originais de volta
    fetchData();
  }
};



  const addQuestion = async () => {
    if (!newQuestion) return;
    await supabase.from('quiz_questions').insert([{ room_id: id, question_text: newQuestion }]);
    setNewQuestion("");
    fetchData();
  };

  const copyToClipboard = () => {
    const url = `${window.location.origin}/room/${id}`;

    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      return;
    }

    // Fallback para navegadores sem clipboard API
    try {
      const textArea = document.createElement('textarea');
      textArea.value = url;
      textArea.style.position = 'fixed';
      textArea.style.opacity = '0';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Erro ao copiar URL', err);
    }
  };

  const ranking = [...guesses].sort((a, b) => 
    Math.abs(a.guess_value - targetValue) - Math.abs(b.guess_value - targetValue)
  );

  if (!room) return <div className="flex items-center justify-center h-screen"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="min-h-screen bg-slate-50/50 pb-20">
      {/* HEADER ESTRUTURADO */}
      <div className="bg-white border-b sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/admin">
              <Button variant="ghost" size="icon"><ArrowLeft className="w-5 h-5" /></Button>
            </Link>
            <div>
              <h1 className="font-bold text-slate-900 leading-tight">{roomName}</h1>
              <div className="flex items-center gap-2">
                 <Badge variant="outline" className="text-[10px] uppercase font-mono">{id.slice(0,8)}</Badge>
                 {room.is_revealed && <Badge className="bg-green-500 text-[10px] h-4">Finalizado</Badge>}
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <Button onClick={copyToClipboard} variant="outline" size="sm" className="hidden sm:flex">
              {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
              {copied ? "Copiado" : "Copiar Link"}
            </Button>
          </div>
        </div>
      </div>

      <main className="max-w-6xl mx-auto p-4 mt-4">
        <Tabs defaultValue="share" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-[600px] mx-auto bg-white border shadow-sm">
            <TabsTrigger value="share"><Share2 className="w-4 h-4 mr-2 hidden sm:block"/> Convite</TabsTrigger>
            <TabsTrigger value="jujuba"><Trophy className="w-4 h-4 mr-2 hidden sm:block"/> Jujubas</TabsTrigger>
            <TabsTrigger value="quiz"><Users className="w-4 h-4 mr-2 hidden sm:block"/> Quiz</TabsTrigger>
            <TabsTrigger value="config"><Settings className="w-4 h-4 mr-2 hidden sm:block"/> Ajustes</TabsTrigger>
          </TabsList>

          {/* ABA 1: COMPARTILHAMENTO */}
          <TabsContent value="share">
            <Card className="border-green-100 shadow-sm">
              <CardContent className="pt-10 flex flex-col items-center text-center">
                <div className="bg-white p-6 rounded-3xl border-4 border-green-50 shadow-xl mb-6">
                  <QRCodeSVG value={`${window.location.origin}/room/${id}`} size={240} fgColor="#166534" />
                </div>
                <h3 className="text-xl font-bold text-slate-800">Seu Código QR está pronto!</h3>
                <p className="text-slate-500 max-w-sm mb-6">Mostre este código para seus convidados ou compartilhe o link direto abaixo.</p>
                <div className="flex w-full max-w-md gap-2 p-2 bg-slate-100 rounded-lg border">
                  <code className="flex-1 text-xs flex items-center px-2 truncate text-slate-600">
                    {window.location.origin}/room/{id}
                  </code>
                  <Button size="sm" onClick={copyToClipboard} className="bg-green-600">
                    {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ABA 2: JUJUBA */}
          <TabsContent value="jujuba" className="space-y-4">
            <div className="grid md:grid-cols-3 gap-4">
              <Card className="md:col-span-1">
                <CardHeader>
                  <CardTitle className="text-lg">Configurar Resultado</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-bold">Quantidade Real no Pote</label>
                    <Input 
                      type="number" 
                      value={targetValue} 
                      onChange={(e) => setTargetValue(Number(e.target.value))} 
                      onBlur={() => handleUpdateRoom('target_value', targetValue)}
                    />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border">
                    <div className="space-y-0.5">
                      <p className="text-sm font-bold">Revelar Ganhador</p>
                      <p className="text-xs text-slate-500">Libera o ranking para os convidados</p>
                    </div>
                    <Switch 
                      checked={room.is_revealed} 
                      onCheckedChange={(val) => handleUpdateRoom('is_revealed', val)} 
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="md:col-span-2">
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">Ranking Atual</CardTitle>
                    <CardDescription>{guesses.length} palpites registrados</CardDescription>
                  </div>
                  <Trophy className="text-yellow-500 w-6 h-6" />
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[300px] pr-4">
                    {ranking.map((g, i) => (
                      <div key={g.id} className="flex items-center justify-between p-3 mb-2 rounded-xl border bg-white shadow-sm">
                        <div className="flex items-center gap-3">
                          <span className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${i === 0 ? 'bg-yellow-400' : 'bg-slate-100'}`}>
                            {i+1}
                          </span>
                          <span className="font-medium text-slate-700">{g.user_name}</span>
                        </div>
                        <div className="text-right">
                           <p className="text-sm font-bold">{g.guess_value} jujubas</p>
                           <p className="text-[10px] text-slate-400">Dif: {Math.abs(g.guess_value - targetValue)}</p>
                        </div>
                      </div>
                    ))}
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* ABA 3: QUIZ */}
              
        <TabsContent value="quiz" className="space-y-6">
          <div className="flex flex-col gap-6">
            
            {/* SEÇÃO DE ADICIONAR PERGUNTA - OCUPA A LARGURA TODA */}
            <Card className="border-green-100 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Gerenciar Perguntas</CardTitle>
                <CardDescription>Adicione as perguntas da dinâmica "Quem é mais provável"</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-col sm:flex-row gap-2">
                  <Input 
                    placeholder="Ex: Quem é mais provável de esquecer as chaves?" 
                    value={newQuestion} 
                    onChange={(e) => setNewQuestion(e.target.value)}
                    className="flex-1"
                  />
                  <Button onClick={addQuestion} className="bg-green-600">
                    <Plus className="w-4 h-4 mr-2"/> Adicionar Pergunta
                  </Button>
                </div>

                <div className="pt-4 border-t">
                  <p className="text-xs font-bold text-slate-500 uppercase mb-3 text-center sm:text-left">Perguntas Cadastradas</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                    {questions.map(q => (
                      <div key={q.id} className="group flex items-center justify-between p-3 text-sm bg-white border rounded-xl hover:border-green-300 transition-colors">
                        <span className="truncate pr-4 font-medium text-slate-600">{q.question_text}</span>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-red-400 hover:text-red-600 hover:bg-red-50 shrink-0" 
                          onClick={() => supabase.from('quiz_questions').delete().eq('id', q.id).then(fetchData)}
                        >
                          <Trash2 className="w-4 h-4"/>
                        </Button>
                      </div>
                    ))}
                  </div>
                  {questions.length === 0 && <p className="text-center py-4 text-slate-400 text-sm italic">Nenhuma pergunta adicionada ainda.</p>}
                </div>
              </CardContent>
            </Card>

            {/* SEÇÃO DE RESULTADOS - AGORA EM LISTA LARGA PARA MELHOR LEITURA */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 px-1">
                <BarChart3 className="text-green-600 w-5 h-5" />
                <h3 className="font-bold text-slate-800 text-lg">Resultados em Tempo Real</h3>
              </div>
              
              <div className="flex flex-col gap-4"> {/* Mudado para flex-col para ocupar largura total */}
                {quizStats.map(stat => (
                  <Card key={stat.id} className="overflow-hidden border-green-100 shadow-sm hover:shadow-md transition-shadow">
                    <div className="grid md:grid-cols-3 items-center">
                      
                      {/* Texto da Pergunta */}
                      <div className="p-4 md:border-r bg-slate-50/50 h-full flex items-center">
                        <p className="font-bold text-slate-700 leading-snug text-base">
                          {stat.question_text}
                        </p>
                      </div>

                      {/* Gráfico de Barras Lado a Lado */}
                      <div className="p-6 md:col-span-2 space-y-5 bg-white">
                        <div className="grid sm:grid-cols-2 gap-6">
                          {/* Parceiro 1 */}
                          <div>
                            <div className="flex justify-between text-xs font-black uppercase mb-2 text-green-700">
                              <span>{partner1}</span>
                              <span>{Math.round((stat.p1Count / stat.total) * 100 || 0)}%</span>
                            </div>
                            <div className="h-4 w-full bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                              <div 
                                className="h-full bg-green-500 transition-all duration-1000 ease-out shadow-[0_0_10px_rgba(34,197,94,0.3)]" 
                                style={{ width: `${(stat.p1Count / stat.total) * 100}%` }}
                              />
                            </div>
                          </div>

                          {/* Parceiro 2 */}
                          <div>
                            <div className="flex justify-between text-xs font-black uppercase mb-2 text-green-900">
                              <span>{partner2}</span>
                              <span>{Math.round((stat.p2Count / stat.total) * 100 || 0)}%</span>
                            </div>
                            <div className="h-4 w-full bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                              <div 
                                className="h-full bg-green-800 transition-all duration-1000 ease-out shadow-[0_0_10px_rgba(22,101,52,0.3)]" 
                                style={{ width: `${(stat.p2Count / stat.total) * 100}%` }}
                              />
                            </div>
                          </div>
                        </div>
                        <div className="flex justify-center">
                          <Badge variant="secondary" className="text-[10px] font-mono">{stat.total} votos totais</Badge>
                        </div>
                      </div>

                    </div>
                  </Card>
                ))}
                
                {quizStats.length === 0 && (
                  <div className="text-center py-10 bg-white border border-dashed rounded-3xl text-slate-400">
                      Aguardando os primeiros votos para gerar os gráficos...
                  </div>
                )}
              </div>
            </div>
          </div>
        </TabsContent>

          {/* ABA 4: AJUSTES */}
          <TabsContent value="config">
            <Card>
              <CardHeader>
                <CardTitle>Configurações Gerais</CardTitle>
                <CardDescription>Gerencie o nome da sala e quem são os participantes.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold">Nome da Sala</label>
                    <Input 
                      value={roomName} 
                      onChange={(e) => setRoomName(e.target.value)} 
                      onBlur={() => handleUpdateRoom('name', roomName)} 
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-bold">Parceiro 1</label>
                      <Input 
                        value={partner1} 
                        onChange={(e) => setPartner1(e.target.value)} 
                        onBlur={() => handleUpdateRoom('partner_1', partner1)} 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-bold">Parceiro 2</label>
                      <Input 
                        value={partner2} 
                        onChange={(e) => setPartner2(e.target.value)} 
                        onBlur={() => handleUpdateRoom('partner_2', partner2)} 
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t flex flex-col gap-4">
                   <h4 className="text-sm font-bold">Controle de Dinâmicas</h4>
                   <div className="flex gap-4">
                      <div className="flex items-center space-x-2 border p-3 rounded-lg flex-1 bg-white">
                        <Switch checked={room.jujuba_active} onCheckedChange={(val) => handleUpdateRoom('jujuba_active', val)} />
                        <label className="text-sm font-medium">Ativar Jujubas</label>
                      </div>
                      <div className="flex items-center space-x-2 border p-3 rounded-lg flex-1 bg-white">
                        <Switch checked={room.quiz_active} onCheckedChange={(val) => handleUpdateRoom('quiz_active', val)} />
                        <label className="text-sm font-medium">Ativar Quiz Casal</label>
                      </div>
                   </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}