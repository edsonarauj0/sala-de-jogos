"use client";
import { useState } from 'react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import AdminDashboard from '@/components/ui/AdminDashboard';

export default function AdminPage() {
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const ADMIN_PASSWORD = "123"; // Defina sua senha aqui

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-green-50">
        <Card className="w-full max-w-sm border-green-200">
          <CardHeader>
            <CardTitle className="text-center text-green-800">Acesso Administrativo</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input 
              type="password" 
              placeholder="Digite a senha" 
              value={password} 
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && (password === ADMIN_PASSWORD ? setIsAuthenticated(true) : alert("Senha Errada"))}
            />
            <Button 
              className="w-full bg-green-600 hover:bg-green-700" 
              onClick={() => password === ADMIN_PASSWORD ? setIsAuthenticated(true) : alert("Senha incorreta")}
            >
              Entrar
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return <AdminDashboard />;
}