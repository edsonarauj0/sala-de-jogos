"use client";
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function Home() {
  const [roomId, setRoomId] = useState('');
  const router = useRouter();

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    if (roomId.trim()) router.push(`/room/${roomId.trim()}`);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-green-50 p-4">
      <Card className="w-full max-w-md border-green-200 shadow-xl">
        <CardHeader className="text-center">
          <CardTitle className="text-green-800 text-3xl font-bold">Jujuba Real 🫙</CardTitle>
          <p className="text-green-600">Insira o código da sala para participar</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleJoin} className="space-y-4">
            <Input 
              placeholder="Ex: 550e8400..." 
              value={roomId} 
              onChange={(e) => setRoomId(e.target.value)}
              className="text-center uppercase font-mono border-green-300"
            />
            <Button className="w-full bg-green-600 hover:bg-green-700 h-12">Entrar na Sala</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}